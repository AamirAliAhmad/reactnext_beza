exports.id = 784;
exports.ids = [784];
exports.modules = {

/***/ 3784:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Common_FunFactTwo_FunFact_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8752);
/* harmony import */ var _components_Common_FunFactTwo_FunFact_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_components_Common_FunFactTwo_FunFact_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);





const FunFactContent = [{
  iconName: "flaticon-user-experience",
  number: "15",
  title: "Years of Experience"
}, {
  iconName: "flaticon-customers",
  number: "600",
  title: "Global Clients"
}, {
  iconName: "flaticon-complete",
  number: "850",
  title: "Delivered Products"
}, {
  iconName: "flaticon-award",
  number: "12",
  title: "Winning Awards"
}];

const FunFact = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
      className: "container",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
        className: (_components_Common_FunFactTwo_FunFact_module_css__WEBPACK_IMPORTED_MODULE_2___default().funfactInnerBox),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
          className: "row justify-content-center pt-100 pb-75",
          children: FunFactContent.map((val, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
            className: "col-lg-3 col-sm-6 col-6",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
              className: (_components_Common_FunFactTwo_FunFact_module_css__WEBPACK_IMPORTED_MODULE_2___default().singleFunfactCard),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
                className: (_components_Common_FunFactTwo_FunFact_module_css__WEBPACK_IMPORTED_MODULE_2___default().icon),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("i", {
                  className: val.iconName
                })
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("h3", {
                children: [val.number, " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
                  className: (_components_Common_FunFactTwo_FunFact_module_css__WEBPACK_IMPORTED_MODULE_2___default().signIcon),
                  children: "+"
                })]
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
                children: val.title
              })]
            })
          }, i))
        })
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FunFact);

/***/ }),

/***/ 8752:
/***/ ((module) => {

// Exports
module.exports = {
	"funfactInnerBox": "FunFact_funfactInnerBox__sCf40",
	"singleFunfactCard": "FunFact_singleFunfactCard__2RsUM",
	"icon": "FunFact_icon__2b5xz",
	"signIcon": "FunFact_signIcon__3sJ7M"
};


/***/ })

};
;