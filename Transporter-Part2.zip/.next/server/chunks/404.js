exports.id = 404;
exports.ids = [404];
exports.modules = {

/***/ 4404:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var _components_Common_OurTeam_OurTeam_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(958);
/* harmony import */ var _components_Common_OurTeam_OurTeam_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_components_Common_OurTeam_OurTeam_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);


 // Team Card Content




const TeamCardContent = [{
  image: "/images/team/team-1.jpg",
  imageAlt: "Team image",
  name: "Albina Josef",
  designation: "President",
  fbIcon: "ri-facebook-line",
  fbLink: "https://www.facebook.com/",
  twiIcon: "ri-twitter-fill",
  twiLink: "https://twitter.com/",
  insIcon: "ri-instagram-fill",
  insLink: "https://www.instagram.com/",
  linIcon: "ri-linkedin-fill",
  linLink: "https://www.linkedin.com/"
}, {
  image: "/images/team/team-2.jpg",
  imageAlt: "Team image",
  name: "Kathryn Pino",
  designation: "Head of HR",
  fbIcon: "ri-facebook-line",
  fbLink: "https://www.facebook.com/",
  twiIcon: "ri-twitter-fill",
  twiLink: "https://twitter.com/",
  insIcon: "ri-instagram-fill",
  insLink: "https://www.instagram.com/",
  linIcon: "ri-linkedin-fill",
  linLink: "https://www.linkedin.com/"
}, {
  image: "/images/team/team-3.jpg",
  imageAlt: "Team image",
  name: "Robert Pease",
  designation: "Delivery Director",
  fbIcon: "ri-facebook-line",
  fbLink: "https://www.facebook.com/",
  twiIcon: "ri-twitter-fill",
  twiLink: "https://twitter.com/",
  insIcon: "ri-instagram-fill",
  insLink: "https://www.instagram.com/",
  linIcon: "ri-linkedin-fill",
  linLink: "https://www.linkedin.com/"
}, {
  image: "/images/team/team-4.jpg",
  imageAlt: "Team image",
  name: "Felicia Jones",
  designation: "Business Development",
  fbIcon: "ri-facebook-line",
  fbLink: "https://www.facebook.com/",
  twiIcon: "ri-twitter-fill",
  twiLink: "https://twitter.com/",
  insIcon: "ri-instagram-fill",
  insLink: "https://www.instagram.com/",
  linIcon: "ri-linkedin-fill",
  linLink: "https://www.linkedin.com/"
}];

const OurTeam = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "team-area pb-75",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
        className: "container",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
          className: "section-title",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {
            children: "OUR TEAM"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("h2", {
            children: "We are a team of IT services and technologies specialists"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
            className: (_components_Common_OurTeam_OurTeam_module_css__WEBPACK_IMPORTED_MODULE_3___default().seeMoreBtn),
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
              href: "/team",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("a", {
                children: "See more Team"
              })
            })
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
          className: "row justify-content-center",
          children: TeamCardContent.map((val, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
            className: "col-lg-3 col-sm-6",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
              className: (_components_Common_OurTeam_OurTeam_module_css__WEBPACK_IMPORTED_MODULE_3___default().singleTeamCard),
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
                className: (_components_Common_OurTeam_OurTeam_module_css__WEBPACK_IMPORTED_MODULE_3___default().teamImage),
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("img", {
                  src: val.image,
                  alt: val.imageAlt
                }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("ul", {
                  className: (_components_Common_OurTeam_OurTeam_module_css__WEBPACK_IMPORTED_MODULE_3___default().actionList),
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("li", {
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("a", {
                      href: val.fbLink,
                      target: "_blank",
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("i", {
                        className: val.fbIcon
                      })
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("li", {
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("a", {
                      href: val.twiLink,
                      target: "_blank",
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("i", {
                        className: val.twiIcon
                      })
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("li", {
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("a", {
                      href: val.insLink,
                      target: "_blank",
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("i", {
                        className: val.insIcon
                      })
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("li", {
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("a", {
                      href: val.linLink,
                      target: "_blank",
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("i", {
                        className: val.linIcon
                      })
                    })
                  })]
                })]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
                className: (_components_Common_OurTeam_OurTeam_module_css__WEBPACK_IMPORTED_MODULE_3___default().teamContent),
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("h3", {
                  children: val.name
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {
                  children: val.designation
                })]
              })]
            })
          }, i))
        })]
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OurTeam);

/***/ }),

/***/ 958:
/***/ ((module) => {

// Exports
module.exports = {
	"singleTeamCard": "OurTeam_singleTeamCard__25Cu9",
	"teamImage": "OurTeam_teamImage__3wwbQ",
	"actionList": "OurTeam_actionList__2Ormx",
	"teamContent": "OurTeam_teamContent__fCDo1",
	"seeMoreBtn": "OurTeam_seeMoreBtn__1CBHW"
};


/***/ })

};
;