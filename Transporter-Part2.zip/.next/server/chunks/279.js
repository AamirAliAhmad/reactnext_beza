exports.id = 279;
exports.ids = [279];
exports.modules = {

/***/ 1279:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var _components_Common_HowCanWeHelp_HowCanWeHelp_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6172);
/* harmony import */ var _components_Common_HowCanWeHelp_HowCanWeHelp_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_components_Common_HowCanWeHelp_HowCanWeHelp_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);







const HowCanWeHelp = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: (_components_Common_HowCanWeHelp_HowCanWeHelp_module_css__WEBPACK_IMPORTED_MODULE_3___default().technologyArea),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
          className: "row align-items-center",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
            className: "col-lg-6 col-md-12",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
              className: (_components_Common_HowCanWeHelp_HowCanWeHelp_module_css__WEBPACK_IMPORTED_MODULE_3___default().technologyContent),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {
                children: "HOW CAN WE HELP YOU?"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("h3", {
                children: "We can help in any way in the field of IT service and technology"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
                children: "Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Praesent sapien massa, convallis a pellentesque nec egestas non nisi. Mauris blandit aliquet elit eget tincidunt nibh pulvinar rutrum congue leo eget malesuada."
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
                className: (_components_Common_HowCanWeHelp_HowCanWeHelp_module_css__WEBPACK_IMPORTED_MODULE_3___default().technologyInnerContent),
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
                  className: (_components_Common_HowCanWeHelp_HowCanWeHelp_module_css__WEBPACK_IMPORTED_MODULE_3___default().number),
                  children: "01"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("h4", {
                  children: "Monthly IT support"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
                  children: "Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Praesent sapien pellentesque nec egestas non nisi."
                })]
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
                className: (_components_Common_HowCanWeHelp_HowCanWeHelp_module_css__WEBPACK_IMPORTED_MODULE_3___default().technologyInnerContent),
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
                  className: (_components_Common_HowCanWeHelp_HowCanWeHelp_module_css__WEBPACK_IMPORTED_MODULE_3___default().number),
                  children: "02"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("h4", {
                  children: "Clear and transparent flat rates"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
                  children: "Vehicula elementum sed sit amet dui. Praesent sapien massa convallis a ellentesque nec egestas non nisi."
                })]
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
            className: "col-lg-6 col-md-12",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
              className: (_components_Common_HowCanWeHelp_HowCanWeHelp_module_css__WEBPACK_IMPORTED_MODULE_3___default().technologyImage),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("img", {
                src: "/images/technology/technology-1.jpg",
                alt: "image"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
                className: (_components_Common_HowCanWeHelp_HowCanWeHelp_module_css__WEBPACK_IMPORTED_MODULE_3___default().contactBtn),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                  href: "/contact",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("a", {
                    className: "default-btn",
                    children: "Contact Us"
                  })
                })
              })]
            })
          })]
        })
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HowCanWeHelp);

/***/ }),

/***/ 6172:
/***/ ((module) => {

// Exports
module.exports = {
	"technologyContent": "HowCanWeHelp_technologyContent__eWH_9",
	"technologyInnerContent": "HowCanWeHelp_technologyInnerContent__KwVpt",
	"number": "HowCanWeHelp_number__2p2p7",
	"technologyImage": "HowCanWeHelp_technologyImage__3RRqP",
	"contactBtn": "HowCanWeHelp_contactBtn__Ac5d8"
};


/***/ })

};
;