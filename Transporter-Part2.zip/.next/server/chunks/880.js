exports.id = 880;
exports.ids = [880];
exports.modules = {

/***/ 1880:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var _components_Common_Testimonials_TestimonialSlider_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7169);
/* harmony import */ var _components_Common_Testimonials_TestimonialSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_components_Common_Testimonials_TestimonialSlider_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const OwlCarousel = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_2__.default)(() => Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 1832, 23)), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(1832)],
    modules: ["..\\components\\Common\\Testimonials\\TestimonialSlider.js -> " + 'react-owl-carousel3']
  }
});




const options = {
  loop: false,
  nav: false,
  dots: true,
  margin: 25,
  autoplayHoverPause: true,
  autoplay: true,
  responsive: {
    0: {
      items: 1
    },
    768: {
      items: 2
    },
    1200: {
      items: 3
    }
  }
}; // Testimonials Content

const TestimonialsContent = [{
  image: "/images/testimonials/testimonials-1.jpg",
  imageAlt: "Client Image",
  name: "Samuel Glenn",
  designation: "Co Founder & CEO",
  feedbackText: "Curabitur aliquet quam id dui posuere blandit. Vivamus suscipit tortor eget felis porttitor volutpat. Nulla quis lorem libero malesuada feugiat. Donec sollicitudin molestie Cras ultricies ligula sed magna dictum porta. Sed porttitor lectus nibh.",
  ratingIcon1: "ri-star-fill",
  ratingIcon2: "ri-star-fill",
  ratingIcon3: "ri-star-fill",
  ratingIcon4: "ri-star-fill",
  ratingIcon5: "ri-star-fill"
}, {
  image: "/images/testimonials/testimonials-2.jpg",
  imageAlt: "Client Image",
  name: "Thomas Bunch",
  designation: "Head of HR",
  feedbackText: "Curabitur aliquet quam id dui posuere blandit. Vivamus suscipit tortor eget felis porttitor volutpat. Nulla quis lorem libero malesuada feugiat. Donec sollicitudin molestie Cras ultricies ligula sed magna dictum porta. Sed porttitor lectus nibh.",
  ratingIcon1: "ri-star-fill",
  ratingIcon2: "ri-star-fill",
  ratingIcon3: "ri-star-fill",
  ratingIcon4: "ri-star-fill",
  ratingIcon5: "ri-star-fill"
}, {
  image: "/images/testimonials/testimonials-3.jpg",
  imageAlt: "Client Image",
  name: "Gladys Wells",
  designation: "React Developer",
  feedbackText: "Curabitur aliquet quam id dui posuere blandit. Vivamus suscipit tortor eget felis porttitor volutpat. Nulla quis lorem libero malesuada feugiat. Donec sollicitudin molestie Cras ultricies ligula sed magna dictum porta. Sed porttitor lectus nibh.",
  ratingIcon1: "ri-star-fill",
  ratingIcon2: "ri-star-fill",
  ratingIcon3: "ri-star-fill",
  ratingIcon4: "ri-star-fill",
  ratingIcon5: "ri-star-fill"
}, {
  image: "/images/testimonials/testimonials-4.jpg",
  imageAlt: "Client Image",
  name: "Olivia",
  designation: "CEO Abc Company",
  feedbackText: "Curabitur aliquet quam id dui posuere blandit. Vivamus suscipit tortor eget felis porttitor volutpat. Nulla quis lorem libero malesuada feugiat. Donec sollicitudin molestie Cras ultricies ligula sed magna dictum porta. Sed porttitor lectus nibh.",
  ratingIcon1: "ri-star-fill",
  ratingIcon2: "ri-star-fill",
  ratingIcon3: "ri-star-fill",
  ratingIcon4: "ri-star-fill",
  ratingIcon5: "ri-star-fill"
}, {
  image: "/images/testimonials/testimonials-5.jpg",
  imageAlt: "Client Image",
  name: "Amelia",
  designation: "UX Designer",
  feedbackText: "Curabitur aliquet quam id dui posuere blandit. Vivamus suscipit tortor eget felis porttitor volutpat. Nulla quis lorem libero malesuada feugiat. Donec sollicitudin molestie Cras ultricies ligula sed magna dictum porta. Sed porttitor lectus nibh.",
  ratingIcon1: "ri-star-fill",
  ratingIcon2: "ri-star-fill",
  ratingIcon3: "ri-star-fill",
  ratingIcon4: "ri-star-fill",
  ratingIcon5: "ri-star-fill"
}];

const TestimonialSlider = () => {
  const [display, setDisplay] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
  react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(() => {
    setDisplay(true);
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      className: (_components_Common_Testimonials_TestimonialSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().testimonialsArea),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
        className: "container ptb-100",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
          className: "section-title-wrap",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
            className: "row",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
              className: "col-lg-8",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("span", {
                children: "TESTIMONIALS"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h2", {
                children: "All the statements that our clients have made about us seeing our work"
              })]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
              className: "col-lg-4",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: "see-more-btn",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                  href: "/testimonials",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                    children: "See more testimonials"
                  })
                })
              })
            })]
          })
        }), display ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(OwlCarousel, _objectSpread(_objectSpread({
          className: "testimonials-slides owl-carousel owl-theme"
        }, options), {}, {
          children: TestimonialsContent.map((val, i) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
            className: (_components_Common_Testimonials_TestimonialSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().singleTestimonialsCard),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
              className: (_components_Common_Testimonials_TestimonialSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().icon),
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                className: "flaticon-straight-quotes"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
              children: val.feedbackText
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
              className: (_components_Common_Testimonials_TestimonialSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().info),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: (_components_Common_Testimonials_TestimonialSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().img),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("img", {
                  src: val.image,
                  alt: val.imageAlt
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h3", {
                children: val.name
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("span", {
                children: val.designation
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
              className: (_components_Common_Testimonials_TestimonialSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().rating),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                className: val.ratingIcon1
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                className: val.ratingIcon2
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                className: val.ratingIcon3
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                className: val.ratingIcon4
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                className: val.ratingIcon5
              })]
            })]
          }, i))
        })) : '']
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TestimonialSlider);

/***/ }),

/***/ 7169:
/***/ ((module) => {

// Exports
module.exports = {
	"singleTestimonialsCard": "TestimonialSlider_singleTestimonialsCard__N_P02",
	"icon": "TestimonialSlider_icon__1T7tY",
	"info": "TestimonialSlider_info__2lD3p",
	"img": "TestimonialSlider_img__38a-w",
	"rating": "TestimonialSlider_rating__1zy-m"
};


/***/ })

};
;