exports.id = 411;
exports.ids = [411];
exports.modules = {

/***/ 9411:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var _components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2591);
/* harmony import */ var _components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const OwlCarousel = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_2__.default)(() => Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 1832, 23)), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(1832)],
    modules: ["..\\components\\Services\\ServiceSliderStyle2\\ServiceSlider.js -> " + 'react-owl-carousel3']
  }
});




const options = {
  loop: true,
  nav: false,
  dots: true,
  smartSpeed: 500,
  margin: 25,
  autoplayHoverPause: true,
  autoplay: true,
  responsive: {
    0: {
      items: 1
    },
    768: {
      items: 2
    },
    1200: {
      items: 4
    }
  }
};

const ServiceSlider = () => {
  const [display, setDisplay] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
  react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(() => {
    setDisplay(true);
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().servicesArea),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
        className: "container ptb-100",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          className: "section-title",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("span", {
            children: "WE PROVIDE SERVICES"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h2", {
            className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().colorWhite),
            children: "The kind of services that our company provides to our clients"
          })]
        }), display ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(OwlCarousel, _objectSpread(_objectSpread({
          className: "services-slides owl-carousel owl-theme"
        }, options), {}, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
            className: `${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().singleServicesCard)} ${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().bgImg1)}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
              className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().icon),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                  className: "flaticon-consulting"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h3", {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                  href: "/services-details",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                    children: "IT Consultancy"
                  })
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
                children: "Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo lacinia eget consectetur sed convallis at tellus."
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                href: "/services-details",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                  className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().servicesBtn),
                  children: "Learn more"
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
            className: `${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().singleServicesCard)} ${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().bgImg2)}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
              className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().icon),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                  className: "flaticon-product-design"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h3", {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                  href: "/services-details",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                    children: "Product Development"
                  })
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
                children: "Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo lacinia eget consectetur sed convallis at tellus."
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                href: "/services-details",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                  className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().servicesBtn),
                  children: "Learn more"
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
            className: `${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().singleServicesCard)} ${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().bgImg3)}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
              className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().icon),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                  className: "flaticon-technical-support"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h3", {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                  href: "/services-details",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                    children: "IT Support"
                  })
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
                children: "Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo lacinia eget consectetur sed convallis at tellus."
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                href: "/services-details",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                  className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().servicesBtn),
                  children: "Learn more"
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
            className: `${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().singleServicesCard)} ${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().bgImg4)}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
              className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().icon),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                  className: "flaticon-cyber-security"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h3", {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                  href: "/services-details",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                    children: "Cyber Security"
                  })
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
                children: "Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo lacinia eget consectetur sed convallis at tellus."
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                href: "/services-details",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                  className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().servicesBtn),
                  children: "Learn more"
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
            className: `${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().singleServicesCard)} ${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().bgImg5)}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
              className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().icon),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                  className: "flaticon-mobile-app"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h3", {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                  href: "/services-details",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                    children: "App Development"
                  })
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
                children: "Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo lacinia eget consectetur sed convallis at tellus."
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                href: "/services-details",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                  className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().servicesBtn),
                  children: "Learn more"
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
            className: `${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().singleServicesCard)} ${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().bgImg5)}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
              className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().icon),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                  className: "flaticon-ux-design"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h3", {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                  href: "/services-details",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                    children: "UX/UI Design"
                  })
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
                children: "Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo lacinia eget consectetur sed convallis at tellus."
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                href: "/services-details",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                  className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().servicesBtn),
                  children: "Learn more"
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
            className: `${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().singleServicesCard)} ${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().bgImg1)}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
              className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().icon),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                  className: "flaticon-web-development"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h3", {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                  href: "/services-details",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                    children: "Web Development"
                  })
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
                children: "Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo lacinia eget consectetur sed convallis at tellus."
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                href: "/services-details",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                  className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().servicesBtn),
                  children: "Learn more"
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
            className: `${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().singleServicesCard)} ${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().bgImg2)}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
              className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().icon),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                  className: "flaticon-digital-marketing"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h3", {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                  href: "/services-details",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                    children: "Digital Marketing"
                  })
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
                children: "Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo lacinia eget consectetur sed convallis at tellus."
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                href: "/services-details",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                  className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().servicesBtn),
                  children: "Learn more"
                })
              })]
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
            className: `${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().singleServicesCard)} ${(_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().bgImg3)}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
              className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().content),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().icon),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                  className: "flaticon-consulting"
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h3", {
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                  href: "/services-details",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                    children: "IT Consultancy"
                  })
                })
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
                children: "Vivamus suscipit tortor eget felis porttitor volutpat. Vivamus magna justo lacinia eget consectetur sed convallis at tellus."
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                href: "/services-details",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                  className: (_components_Services_ServiceSliderStyle2_ServiceSlider_module_css__WEBPACK_IMPORTED_MODULE_4___default().servicesBtn),
                  children: "Learn more"
                })
              })]
            })
          })]
        })) : '']
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ServiceSlider);

/***/ }),

/***/ 2591:
/***/ ((module) => {

// Exports
module.exports = {
	"servicesArea": "ServiceSlider_servicesArea__17rOi",
	"singleServicesCard": "ServiceSlider_singleServicesCard__1xDKP",
	"content": "ServiceSlider_content__DmVtn",
	"icon": "ServiceSlider_icon__1maWG",
	"servicesBtn": "ServiceSlider_servicesBtn__2QXo-",
	"bgImg1": "ServiceSlider_bgImg1__2VBuf",
	"bgImg2": "ServiceSlider_bgImg2__3CKOG",
	"bgImg3": "ServiceSlider_bgImg3__LZGkl",
	"bgImg4": "ServiceSlider_bgImg4__1D1DP",
	"bgImg5": "ServiceSlider_bgImg5__366td"
};


/***/ })

};
;