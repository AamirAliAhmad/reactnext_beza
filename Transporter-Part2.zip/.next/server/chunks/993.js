exports.id = 993;
exports.ids = [993];
exports.modules = {

/***/ 5993:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var _components_Common_OurBlog_OurBlog_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3829);
/* harmony import */ var _components_Common_OurBlog_OurBlog_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_components_Common_OurBlog_OurBlog_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);


 // Blog Card Content




const BlogCardContent = [{
  image: "/images/blog/blog-1.jpg",
  imageAlt: "Blog Image",
  title: "How is technology working with new things?",
  date: "14 June, 2021",
  author: "Brandy",
  authorLink: "/author",
  viewDetailsLink: "/blog-details"
}, {
  image: "/images/blog/blog-2.jpg",
  imageAlt: "Blog Image",
  title: "Top 10 important tips on IT services & technology",
  date: "15 June, 2021",
  author: "Garcia",
  authorLink: "/author",
  viewDetailsLink: "/blog-details"
}, {
  image: "/images/blog/blog-3.jpg",
  imageAlt: "Blog Image",
  title: "What are the benefits of IT support service and technology?",
  date: "14 June, 2021",
  author: "Williams",
  authorLink: "/author",
  viewDetailsLink: "/blog-details"
}];

const OurBlog = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: (_components_Common_OurBlog_OurBlog_module_css__WEBPACK_IMPORTED_MODULE_3___default().blogArea),
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
        className: "container pt-100 pb-75",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
          className: "section-title",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {
            children: "OUR BLOG"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("h2", {
            children: "Read our latest news & blog which is updated regularly"
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
          className: "row justify-content-center",
          children: BlogCardContent.map((val, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
            className: "col-lg-4 col-md-6",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
              className: (_components_Common_OurBlog_OurBlog_module_css__WEBPACK_IMPORTED_MODULE_3___default().singleBlogCard),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
                className: (_components_Common_OurBlog_OurBlog_module_css__WEBPACK_IMPORTED_MODULE_3___default().postImage),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                  href: val.viewDetailsLink,
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("a", {
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("img", {
                      src: val.image,
                      alt: val.imageAlt
                    })
                  })
                })
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
                className: (_components_Common_OurBlog_OurBlog_module_css__WEBPACK_IMPORTED_MODULE_3___default().postContent),
                children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("ul", {
                  className: (_components_Common_OurBlog_OurBlog_module_css__WEBPACK_IMPORTED_MODULE_3___default().entryMeta),
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("li", {
                    children: val.date
                  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("li", {
                    children: ["by: ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                      href: val.authorLink,
                      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("a", {
                        children: val.author
                      })
                    })]
                  })]
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("h3", {
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
                    href: val.viewDetailsLink,
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("a", {
                      children: val.title
                    })
                  })
                })]
              })]
            })
          }, i))
        })]
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OurBlog);

/***/ }),

/***/ 3829:
/***/ ((module) => {

// Exports
module.exports = {
	"singleBlogCard": "OurBlog_singleBlogCard__12M25",
	"postImage": "OurBlog_postImage__1sroN",
	"postContent": "OurBlog_postContent__3hHjW",
	"entryMeta": "OurBlog_entryMeta__2nZF1"
};


/***/ })

};
;