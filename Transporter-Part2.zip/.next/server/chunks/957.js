exports.id = 957;
exports.ids = [957];
exports.modules = {

/***/ 957:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_datepicker__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9008);
/* harmony import */ var react_datepicker__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_datepicker__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var _components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7227);
/* harmony import */ var _components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);



const ModalVideo = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_2__.default)(() => Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 6616, 23)), {
  ssr: false,
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(6616)],
    modules: ["..\\components\\Appointment\\AppointmentStyle2\\AppointmentForm.js -> " + 'react-modal-video']
  }
});





const AppointmentForm = () => {
  const {
    0: startDate,
    1: setStartDate
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(new Date()); // Popup Video

  const [isOpen, setIsOpen] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(true);

  const openModal = () => {
    setIsOpen(!isOpen);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(ModalVideo, {
      channel: "youtube",
      isOpen: !isOpen,
      videoId: "bk7McNUjWgw",
      onClose: () => setIsOpen(!isOpen)
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().appointmentArea),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        className: "container ptb-100",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          className: "row align-items-center",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
            className: "col-lg-6 col-md-12",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
              className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().appointmentVideo),
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                onClick: e => {
                  e.preventDefault();
                  openModal();
                },
                className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().videoBtn),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("i", {
                  className: "ri-play-fill"
                })
              })
            })
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
            className: "col-lg-6 col-md-12",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
              className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().appointmentFormWrap),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().content),
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h3", {
                  children: "Make an appointment"
                })
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("form", {
                className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().appointmentForm),
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                  className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("input", {
                    type: "text",
                    className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formControl),
                    placeholder: "Enter your name"
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                  className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("input", {
                    type: "text",
                    className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formControl),
                    placeholder: "Email address"
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                  className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx((react_datepicker__WEBPACK_IMPORTED_MODULE_1___default()), {
                    selected: startDate,
                    onChange: date => setStartDate(date),
                    className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formControl)
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                  className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                    className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formSelect),
                    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("select", {
                      className: "form-select",
                      "aria-label": "Default select example",
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("option", {
                        children: "Select service"
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("option", {
                        defaultValue: "1",
                        children: "Software development"
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("option", {
                        defaultValue: "2",
                        children: "Website development"
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("option", {
                        defaultValue: "3",
                        children: "Social media marketing"
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("option", {
                        defaultValue: "4",
                        children: "Competitor research"
                      })]
                    })
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
                  className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("textarea", {
                    name: "message",
                    className: (_components_Appointment_AppointmentStyle2_AppointmentForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formControl),
                    placeholder: "Write message...",
                    rows: "5"
                  })
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("button", {
                  type: "submit",
                  className: "default-btn border-0 w-100",
                  children: "Submit"
                })]
              })]
            })
          })]
        })
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppointmentForm);

/***/ }),

/***/ 7227:
/***/ ((module) => {

// Exports
module.exports = {
	"appointmentArea": "AppointmentForm_appointmentArea__3rp_d",
	"appointmentVideo": "AppointmentForm_appointmentVideo__3WW2N",
	"videoBtn": "AppointmentForm_videoBtn__1rYr-",
	"ripple": "AppointmentForm_ripple__2piJY",
	"appointmentFormWrap": "AppointmentForm_appointmentFormWrap__3w7ix",
	"content": "AppointmentForm_content__3IRUw",
	"appointmentForm": "AppointmentForm_appointmentForm__1_Z_F",
	"formGroup": "AppointmentForm_formGroup__15VAz",
	"formControl": "AppointmentForm_formControl__2E3ZQ",
	"formSelect": "AppointmentForm_formSelect__1ypMT",
	"default-btn": "AppointmentForm_default-btn__28f-w"
};


/***/ })

};
;