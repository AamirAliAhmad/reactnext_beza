(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 2598:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: ./node_modules/react-datepicker/dist/react-datepicker.css
var react_datepicker = __webpack_require__(5994);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
;// CONCATENATED MODULE: external "styled-jsx/style"
const style_namespaceObject = require("styled-jsx/style");
var style_default = /*#__PURE__*/__webpack_require__.n(style_namespaceObject);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/_App/GoTop.js






const GoTop = ({
  scrollStepInPx,
  delayInMs
}) => {
  const [thePosition, setThePosition] = external_react_default().useState(false);
  const timeoutRef = external_react_default().useRef(null);
  external_react_default().useEffect(() => {
    document.addEventListener("scroll", () => {
      if (window.scrollY > 170) {
        setThePosition(true);
      } else {
        setThePosition(false);
      }
    });
  }, []);

  const onScrollStep = () => {
    if (window.pageYOffset === 0) {
      clearInterval(timeoutRef.current);
    }

    window.scroll(0, window.pageYOffset - scrollStepInPx);
  };

  const scrollToTop = () => {
    timeoutRef.current = setInterval(onScrollStep, delayInMs);
  };

  const renderGoTopIcon = () => {
    return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        onClick: scrollToTop,
        className: "jsx-624410714" + " " + `go-top ${thePosition ? 'active' : ''}`,
        children: [/*#__PURE__*/jsx_runtime_.jsx("i", {
          className: "jsx-624410714" + " " + 'ri-arrow-up-s-line'
        }), /*#__PURE__*/jsx_runtime_.jsx((style_default()), {
          id: "624410714",
          children: [".go-top.jsx-624410714{position:fixed;cursor:pointer;bottom:-100px;right:20px;color:var(--white-color);background-color:var(--main-color);z-index:4;width:45px;text-align:center;height:45px;opacity:0;visibility:hidden;border-radius:50%;font-size:22px;-webkit-transition:var(--transition);transition:var(--transition);overflow:hidden;box-shadow:0px 3px 10px rgba(0,0,0,0.1);}", ".go-top.jsx-624410714 i.jsx-624410714{position:absolute;right:0;left:0;top:45%;-webkit-transform:translateY(-45%);-ms-transform:translateY(-45%);transform:translateY(-45%);text-align:center;font-size:30px;margin-left:auto;margin-right:auto;}", ".go-top.active.jsx-624410714{opacity:1;visibility:visible;bottom:20px;}", ".go-top.jsx-624410714:hover{background-color:var(--optional-color);color:var(--white-color);-webkit-transition:var(--transition);transition:var(--transition);box-shadow:0 4px 6px rgba(50,50,93,.11),0 1px 3px rgba(0,0,0,.08);-webkit-transform:translateY(-5px);-ms-transform:translateY(-5px);transform:translateY(-5px);}"]
        })]
      })
    });
  };

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: renderGoTopIcon()
  });
};

/* harmony default export */ const _App_GoTop = (GoTop);
// EXTERNAL MODULE: ./components/_App/Preloader/Preloader.module.css
var Preloader_module = __webpack_require__(6065);
var Preloader_module_default = /*#__PURE__*/__webpack_require__.n(Preloader_module);
;// CONCATENATED MODULE: ./components/_App/Preloader/Preloader.js






const Preloader = () => {
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Preloader_module_default()).preloader,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (Preloader_module_default()).loader,
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (Preloader_module_default()).shadow
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (Preloader_module_default()).box
        })]
      })
    })
  });
};

/* harmony default export */ const Preloader_Preloader = (Preloader);
;// CONCATENATED MODULE: ./components/_App/Layout.js








const Layout = ({
  children
}) => {
  // Preloader
  const [loader, setLoader] = external_react_default().useState(true);
  external_react_default().useEffect(() => {
    setTimeout(() => setLoader(false), 1500);
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("meta", {
        charSet: "utf-8"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "viewport",
        content: "width=device-width, initial-scale=1"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "icon",
        type: "image/png",
        href: "/images/favicon.png"
      }), /*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "Biza - React Next.js IT Solutions & Services Template"
      })]
    }), children, loader ? /*#__PURE__*/jsx_runtime_.jsx(Preloader_Preloader, {}) : null, /*#__PURE__*/jsx_runtime_.jsx(_App_GoTop, {
      scrollStepInPx: "100",
      delayInMs: "10.50"
    })]
  });
};

/* harmony default export */ const _App_Layout = (Layout);
;// CONCATENATED MODULE: ./pages/_app.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








 // Global CSS






const MyApp = ({
  Component,
  pageProps
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(_App_Layout, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Component, _objectSpread({}, pageProps))
  });
};

/* harmony default export */ const _app = (MyApp);

/***/ }),

/***/ 6065:
/***/ ((module) => {

// Exports
module.exports = {
	"preloader": "Preloader_preloader__3pP-8",
	"loader": "Preloader_loader__2Kq9N",
	"box": "Preloader_box__28FZU",
	"animate": "Preloader_animate__3mhJO",
	"shadow": "Preloader_shadow__1roAT"
};


/***/ }),

/***/ 5994:
/***/ (() => {



/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2598));
module.exports = __webpack_exports__;

})();